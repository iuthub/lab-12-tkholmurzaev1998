## Landing page website 

![preview](src/images/scroll-eff.gif)

A landing page website based on bootstrap 4 for educational purpose 

** See The [article on medium ](https://medium.com/@hayanisaid1995/learn-bootstrap-4-in-30-minute-by-building-a-landing-page-website-guide-for-beginners-f64e03833f33) 
